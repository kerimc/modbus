﻿namespace client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstStopBits = new System.Windows.Forms.ComboBox();
            this.lstDataBits = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lstParity = new System.Windows.Forms.ComboBox();
            this.lstBaudrate = new System.Windows.Forms.ComboBox();
            this.lstPorts = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.txtSampleRate = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.AS410 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.pictureBoxDigitalOut1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDigitalOut2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDigitalOut3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDigitalOut4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDigitalOut5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDigitalOut6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDigitalOut7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDigitalOut8 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.AS410.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut8)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstStopBits);
            this.groupBox1.Controls.Add(this.lstDataBits);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lstParity);
            this.groupBox1.Controls.Add(this.lstBaudrate);
            this.groupBox1.Controls.Add(this.lstPorts);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(178, 192);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PC Port Info";
            // 
            // lstStopBits
            // 
            this.lstStopBits.FormattingEnabled = true;
            this.lstStopBits.Location = new System.Drawing.Point(90, 128);
            this.lstStopBits.Name = "lstStopBits";
            this.lstStopBits.Size = new System.Drawing.Size(82, 21);
            this.lstStopBits.TabIndex = 10;
            // 
            // lstDataBits
            // 
            this.lstDataBits.FormattingEnabled = true;
            this.lstDataBits.Location = new System.Drawing.Point(90, 101);
            this.lstDataBits.Name = "lstDataBits";
            this.lstDataBits.Size = new System.Drawing.Size(82, 21);
            this.lstDataBits.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Stop bits";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Data bits";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Parity:";
            // 
            // lstParity
            // 
            this.lstParity.FormattingEnabled = true;
            this.lstParity.Location = new System.Drawing.Point(90, 70);
            this.lstParity.Name = "lstParity";
            this.lstParity.Size = new System.Drawing.Size(82, 21);
            this.lstParity.TabIndex = 5;
            // 
            // lstBaudrate
            // 
            this.lstBaudrate.FormattingEnabled = true;
            this.lstBaudrate.Location = new System.Drawing.Point(90, 40);
            this.lstBaudrate.Name = "lstBaudrate";
            this.lstBaudrate.Size = new System.Drawing.Size(82, 21);
            this.lstBaudrate.TabIndex = 3;
            // 
            // lstPorts
            // 
            this.lstPorts.FormattingEnabled = true;
            this.lstPorts.Location = new System.Drawing.Point(90, 13);
            this.lstPorts.Name = "lstPorts";
            this.lstPorts.Size = new System.Drawing.Size(82, 21);
            this.lstPorts.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Baudrate:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Port:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(286, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 4;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 551);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1027, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(21, 232);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 6;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click_1);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(115, 232);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 7;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click_1);
            // 
            // txtSampleRate
            // 
            this.txtSampleRate.Location = new System.Drawing.Point(21, 277);
            this.txtSampleRate.Name = "txtSampleRate";
            this.txtSampleRate.Size = new System.Drawing.Size(100, 20);
            this.txtSampleRate.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.AS410);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(286, 66);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(704, 482);
            this.tabControl1.TabIndex = 9;
            // 
            // AS410
            // 
            this.AS410.Controls.Add(this.groupBox3);
            this.AS410.Controls.Add(this.groupBox2);
            this.AS410.Controls.Add(this.label6);
            this.AS410.Location = new System.Drawing.Point(4, 22);
            this.AS410.Name = "AS410";
            this.AS410.Padding = new System.Windows.Forms.Padding(3);
            this.AS410.Size = new System.Drawing.Size(696, 456);
            this.AS410.TabIndex = 0;
            this.AS410.Text = "AS410";
            this.AS410.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.checkBox8);
            this.groupBox3.Controls.Add(this.checkBox7);
            this.groupBox3.Controls.Add(this.checkBox6);
            this.groupBox3.Controls.Add(this.checkBox5);
            this.groupBox3.Controls.Add(this.checkBox4);
            this.groupBox3.Controls.Add(this.checkBox3);
            this.groupBox3.Controls.Add(this.checkBox2);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Controls.Add(this.pictureBoxDigitalOut1);
            this.groupBox3.Controls.Add(this.pictureBoxDigitalOut2);
            this.groupBox3.Controls.Add(this.pictureBoxDigitalOut3);
            this.groupBox3.Controls.Add(this.pictureBoxDigitalOut4);
            this.groupBox3.Controls.Add(this.pictureBoxDigitalOut5);
            this.groupBox3.Controls.Add(this.pictureBoxDigitalOut6);
            this.groupBox3.Controls.Add(this.pictureBoxDigitalOut7);
            this.groupBox3.Controls.Add(this.pictureBoxDigitalOut8);
            this.groupBox3.Location = new System.Drawing.Point(28, 144);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(292, 160);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Digital Outputs";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 95);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // pictureBoxDigitalOut1
            // 
            this.pictureBoxDigitalOut1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDigitalOut1.Location = new System.Drawing.Point(240, 36);
            this.pictureBoxDigitalOut1.Name = "pictureBoxDigitalOut1";
            this.pictureBoxDigitalOut1.Size = new System.Drawing.Size(26, 21);
            this.pictureBoxDigitalOut1.TabIndex = 8;
            this.pictureBoxDigitalOut1.TabStop = false;
            // 
            // pictureBoxDigitalOut2
            // 
            this.pictureBoxDigitalOut2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDigitalOut2.Location = new System.Drawing.Point(208, 36);
            this.pictureBoxDigitalOut2.Name = "pictureBoxDigitalOut2";
            this.pictureBoxDigitalOut2.Size = new System.Drawing.Size(26, 21);
            this.pictureBoxDigitalOut2.TabIndex = 7;
            this.pictureBoxDigitalOut2.TabStop = false;
            // 
            // pictureBoxDigitalOut3
            // 
            this.pictureBoxDigitalOut3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDigitalOut3.Location = new System.Drawing.Point(176, 36);
            this.pictureBoxDigitalOut3.Name = "pictureBoxDigitalOut3";
            this.pictureBoxDigitalOut3.Size = new System.Drawing.Size(26, 21);
            this.pictureBoxDigitalOut3.TabIndex = 6;
            this.pictureBoxDigitalOut3.TabStop = false;
            // 
            // pictureBoxDigitalOut4
            // 
            this.pictureBoxDigitalOut4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDigitalOut4.Location = new System.Drawing.Point(144, 36);
            this.pictureBoxDigitalOut4.Name = "pictureBoxDigitalOut4";
            this.pictureBoxDigitalOut4.Size = new System.Drawing.Size(26, 21);
            this.pictureBoxDigitalOut4.TabIndex = 5;
            this.pictureBoxDigitalOut4.TabStop = false;
            // 
            // pictureBoxDigitalOut5
            // 
            this.pictureBoxDigitalOut5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDigitalOut5.Location = new System.Drawing.Point(102, 36);
            this.pictureBoxDigitalOut5.Name = "pictureBoxDigitalOut5";
            this.pictureBoxDigitalOut5.Size = new System.Drawing.Size(26, 21);
            this.pictureBoxDigitalOut5.TabIndex = 4;
            this.pictureBoxDigitalOut5.TabStop = false;
            // 
            // pictureBoxDigitalOut6
            // 
            this.pictureBoxDigitalOut6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDigitalOut6.Location = new System.Drawing.Point(70, 36);
            this.pictureBoxDigitalOut6.Name = "pictureBoxDigitalOut6";
            this.pictureBoxDigitalOut6.Size = new System.Drawing.Size(26, 21);
            this.pictureBoxDigitalOut6.TabIndex = 3;
            this.pictureBoxDigitalOut6.TabStop = false;
            // 
            // pictureBoxDigitalOut7
            // 
            this.pictureBoxDigitalOut7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDigitalOut7.Location = new System.Drawing.Point(38, 36);
            this.pictureBoxDigitalOut7.Name = "pictureBoxDigitalOut7";
            this.pictureBoxDigitalOut7.Size = new System.Drawing.Size(26, 21);
            this.pictureBoxDigitalOut7.TabIndex = 2;
            this.pictureBoxDigitalOut7.TabStop = false;
            // 
            // pictureBoxDigitalOut8
            // 
            this.pictureBoxDigitalOut8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDigitalOut8.Location = new System.Drawing.Point(6, 36);
            this.pictureBoxDigitalOut8.Name = "pictureBoxDigitalOut8";
            this.pictureBoxDigitalOut8.Size = new System.Drawing.Size(26, 21);
            this.pictureBoxDigitalOut8.TabIndex = 1;
            this.pictureBoxDigitalOut8.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox8);
            this.groupBox2.Controls.Add(this.pictureBox7);
            this.groupBox2.Controls.Add(this.pictureBox6);
            this.groupBox2.Controls.Add(this.pictureBox5);
            this.groupBox2.Controls.Add(this.pictureBox4);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Location = new System.Drawing.Point(28, 43);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(292, 73);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Digital Inputs";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox8.Location = new System.Drawing.Point(240, 36);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(26, 21);
            this.pictureBox8.TabIndex = 8;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(208, 36);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(26, 21);
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Location = new System.Drawing.Point(176, 36);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(26, 21);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(144, 36);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(26, 21);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(102, 36);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(26, 21);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(70, 36);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(26, 21);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(38, 36);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(26, 21);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(6, 36);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(26, 21);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(696, 456);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(696, 456);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Control Digital Out";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(38, 95);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 11;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(70, 95);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 12;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(102, 95);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 13;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(144, 95);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 14;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(176, 95);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 15;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(208, 95);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 16;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(240, 95);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(15, 14);
            this.checkBox8.TabIndex = 17;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 121);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 33);
            this.button1.TabIndex = 18;
            this.button1.Text = "Write";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1027, 573);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtSampleRate);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.AS410.ResumeLayout(false);
            this.AS410.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDigitalOut8)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox lstBaudrate;
        private System.Windows.Forms.ComboBox lstPorts;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox lstParity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox lstStopBits;
        private System.Windows.Forms.ComboBox lstDataBits;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TextBox txtSampleRate;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage AS410;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBoxDigitalOut1;
        private System.Windows.Forms.PictureBox pictureBoxDigitalOut2;
        private System.Windows.Forms.PictureBox pictureBoxDigitalOut3;
        private System.Windows.Forms.PictureBox pictureBoxDigitalOut4;
        private System.Windows.Forms.PictureBox pictureBoxDigitalOut5;
        private System.Windows.Forms.PictureBox pictureBoxDigitalOut6;
        private System.Windows.Forms.PictureBox pictureBoxDigitalOut7;
        private System.Windows.Forms.PictureBox pictureBoxDigitalOut8;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
    }
}

